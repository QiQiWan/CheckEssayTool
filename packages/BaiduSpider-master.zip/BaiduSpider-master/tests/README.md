# BaiduSpider测试

这里是BaiduSpider的单元测试，如果要运行它，执行

```bash
python tests/__init__.py
```

就可以运行了。文档正在编写中。
